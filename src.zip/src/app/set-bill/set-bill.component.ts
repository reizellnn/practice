import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-set-bill',
  templateUrl: './set-bill.component.html',
  styleUrls: ['./set-bill.component.scss'],
})
export class SetBillComponent  implements OnInit {

  constructor() { }

  ngOnInit() {}

}
